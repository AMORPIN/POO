class SesionAula:
    """Representa una sesión de uso de un aula."""

    # Atributos de clase
    centro = "CFGS Python"
    total_sesiones = 0

    def __init__(self, aula: str, profesor: str,
                 alumnos: int, log_path: str):
        """Inicializa y valida los datos de una sesión."""

        if not isinstance(aula, str) or not aula.strip():
            raise ValueError("El nombre del aula no puede estar vacío.")

        if not isinstance(profesor, str) or not profesor.strip():
            raise ValueError("El nombre del profesor no puede estar vacío.")

        if isinstance(alumnos, bool) or not isinstance(alumnos, int):
            raise TypeError("El número de alumnos debe ser un entero.")

        if alumnos <= 0:
            raise ValueError("Debe haber al menos un alumno.")

        if not isinstance(log_path, str) or not log_path.strip():
            raise ValueError("La ruta del registro no puede estar vacía.")

        # Normalizar los datos
        self.aula = aula.strip()
        self.profesor = profesor.strip()
        self.alumnos = alumnos
        self.log_path = log_path.strip()

        # Atributos internos
        self._log = None
        self._cerrada = False

        # Incrementar el número total de sesiones
        SesionAula.total_sesiones += 1

    def __enter__(self):
        """Abre el registro al entrar en el bloque with."""

        if self._cerrada:
            raise RuntimeError("La sesión ya está cerrada.")

        self._log = open(
            self.log_path,
            "a",
            encoding="utf-8"
        )

        self._log.write(
            f"Inicio de sesión: aula {self.aula}, "
            f"profesor {self.profesor}, "
            f"alumnos {self.alumnos}\n"
        )

        return self

    def __exit__(self, tipo, valor, traceback):
        """Cierra el registro al salir del bloque with."""

        try:
            if self._log is not None:
                if tipo is None:
                    self._log.write("Fin de sesión: correcta\n")
                else:
                    self._log.write(
                        f"Fin de sesión con error: {valor}\n"
                    )
        finally:
            if self._log is not None:
                self._log.close()
                self._log = None

            self._cerrada = True

        # False significa que no se oculta la excepción
        return False

    def registrar(self, mensaje: str) -> None:
        """Escribe un mensaje en el registro de la sesión."""

        if self._log is None or self._log.closed:
            raise RuntimeError("El registro no está abierto.")

        if not isinstance(mensaje, str):
            raise TypeError("El mensaje debe ser una cadena.")

        self._log.write(mensaje + "\n")

    def __del__(self):
        """Avisa si la sesión no se ha cerrado correctamente."""

        try:
            if not self._cerrada:
                print(
                    f"AVISO: La sesión del aula "
                    f"{self.aula} no se cerró correctamente."
                )
        except Exception:
            # Evita errores durante el apagado del intérprete
            pass


# PROGRAMA PRINCIPAL
if __name__ == "__main__":

    print("=== CREACIÓN DE SESIONES ===")

    sesion1 = SesionAula(
        "Aula 1",
        "Laura",
        20,
        "registro_aula1.txt"
    )

    sesion2 = SesionAula(
        "Aula 2",
        "Carlos",
        15,
        "registro_aula2.txt"
    )

    # Mostrar los datos de los objetos
    print("=== DATOS DE LAS SESIONES ===")
    print(sesion1.__dict__)
    print(sesion2.__dict__)

    # Comprobar tipos e instancias
    print("=== TIPOS E INSTANCIAS ===")
    print(type(sesion1))
    print(isinstance(sesion1, SesionAula))
    print(type(sesion2))
    print(isinstance(sesion2, SesionAula))

    # Diferencia entre clase e instancia
    print("=== ATRIBUTOS DE CLASE E INSTANCIA ===")
    print("Centro:", SesionAula.centro)
    print("Total de sesiones:", SesionAula.total_sesiones)
    print("Aula de la primera sesión:", sesion1.aula)

    # Primera sesión
    print("=== PRIMERA SESIÓN ===")

    with sesion1 as sesion:
        sesion.registrar("Se inicia la clase de Python.")
        sesion.registrar("Se utilizan 10 ordenadores.")

    print("Primera sesión cerrada correctamente.")

    # Segunda sesión
    print("=== SEGUNDA SESIÓN ===")

    try:
        with sesion2 as sesion:
            sesion.registrar("Comienza la clase.")
            raise ValueError("Error de prueba durante la sesión.")

    except ValueError as error:
        print("Excepción detectada:", error)

    print("La segunda sesión también se ha cerrado.")

    # Comprobar el estado final
    print("=== RESULTADO FINAL ===")
    print("Sesión 1 cerrada:", sesion1._cerrada)
    print("Sesión 2 cerrada:", sesion2._cerrada)
    print("Total de sesiones:", SesionAula.total_sesiones)
