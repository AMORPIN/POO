
# Gestión de sesiones de aula

## 1. Explicación del modelo

El programa utiliza una clase llamada SesionAula para representar el uso de las aulas de un centro de formación.

Cada sesión contiene el nombre del aula, el profesor, el número de alumnos y la ruta del archivo donde se guarda el registro.

La clase también dispone de dos atributos compartidos: centro y total_sesiones.

El programa valida los datos antes de crear cada sesión y utiliza el bloque with para abrir y cerrar los archivos de registro de forma segura.

## 2. Diferencia entre clase e instancia

Los atributos de clase pertenecen a la clase y son compartidos por todos sus objetos.

En este programa son:
- centro
- total_sesiones

Los atributos de instancia pertenecen a cada objeto y pueden tener valores diferentes.

Por ejemplo:
- aula
- profesor
- alumnos
- log_path
- _log
- _cerrada

## 3. Explicación de __init__, __new__ y __del__

__new__ es un método especial que se encarga de crear y devolver una nueva instancia de una clase. Normalmente no es necesario modificarlo.

__init__ inicializa el objeto después de su creación. En esta práctica comprueba que los datos sean correctos e inicializa los atributos.

__del__ es un método que puede ejecutarse cuando un objeto va a ser destruido. En nuestro programa muestra un aviso si la sesión no se ha cerrado correctamente.

## 4. Justificación del uso de with

Se utiliza with para gestionar de forma segura los archivos de registro.

Al entrar en el bloque se ejecuta __enter__, que abre el archivo.

Al salir del bloque se ejecuta __exit__, que escribe el final del registro y cierra el archivo.

Esto también ocurre cuando se produce una excepción.

## 5. Ejemplos de ejecución

Se crean dos sesiones:
- Aula 1, con la profesora Laura y 20 alumnos.
- Aula 2, con el profesor Carlos y 15 alumnos.

La primera sesión termina correctamente.

En la segunda se provoca una excepción de prueba. Aunque se produce el error, el método __exit__ se ejecuta y cierra el archivo.

El resultado final muestra que las dos sesiones están cerradas y que el total de sesiones creadas es 2.

También se generan los archivos registro_aula1.txt y registro_aula2.txt.

## 6. Limitaciones de __del__

El método __del__ no garantiza que un recurso se cierre en un momento determinado.

Python no garantiza cuándo se ejecutará este método y puede haber problemas durante el apagado del intérprete.

Por eso no se utiliza como mecanismo principal para cerrar archivos.

La forma recomendada en esta práctica es utilizar with, porque permite cerrar los recursos de manera controlada incluso cuando se produce una excepción.
