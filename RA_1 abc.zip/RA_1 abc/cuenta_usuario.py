class CuentaUsuario:
    #Representa una cuenta de usuario de la plataforma.

    # Atributos de clase
    MAX_INTENTOS = 3
    dominio = "formacion.local"

    def __init__(self, nombre: str, email: str, password_hash: str):
        "Inicializa una cuenta de usuario."""
        self.nombre = nombre
        self._email = email
        self.__password_hash = password_hash
        self._activa = True
        self._intentos_fallidos = 0

    # Métodos consultores
    def esta_activa(self) -> bool:
        """Indica si la cuenta está activa."""
        return self._activa

    def puede_iniciar_sesion(self) -> bool:
        """Comprueba si se puede iniciar sesión."""
        return self._activa

    def perfil_publico(self) -> str:
        """Devuelve la información pública del usuario."""
        return f"Nombre: {self.nombre}"

    def consultar_email(self) -> str:
        """Devuelve el email del usuario."""
        return self._email

    # Métodos modificadores
    def activar(self) -> None:
        """Activa la cuenta."""
        self._activa = True

    def desactivar(self) -> None:
        """Desactiva la cuenta."""
        self._activa = False

    def cambiar_email(self, nuevo_email: str) -> None:
        """Cambia el email si tiene un formato válido."""
        if not isinstance(nuevo_email, str):
            raise TypeError("El email debe ser una cadena.")

        if (
            "@" not in nuevo_email
            or not nuevo_email.endswith("@" + self.dominio)
        ):
            raise ValueError(
                f"El email debe contener @ y terminar en "
                f"@{self.dominio}"
            )

        self._email = nuevo_email

    def registrar_intento_fallido(self) -> None:
        """Registra un fallo y desactiva la cuenta al llegar al límite."""
        self._intentos_fallidos += 1

        if self._intentos_fallidos >= self.MAX_INTENTOS:
            self.desactivar()

    def reiniciar_intentos(self) -> None:
        """Pone el contador de intentos fallidos a cero."""
        self._intentos_fallidos = 0


# PROGRAMA PRINCIPAL
if __name__ == "__main__":

    # Crear dos cuentas
    cuenta1 = CuentaUsuario(
        "Laura",
        "laura@formacion.local",
        "hash_laura_123"
    )

    cuenta2 = CuentaUsuario(
        "Carlos",
        "carlos@formacion.local",
        "hash_carlos_456"
    )

    # Mostrar información de las cuentas
    print("=== CUENTAS CREADAS ===")
    print(cuenta1.__dict__)
    print(cuenta2.__dict__)

    # Comprobar que son objetos distintos
    print("=== IDENTIDAD DE LOS OBJETOS ===")
    print("¿Son el mismo objeto?", cuenta1 is cuenta2)
    print("ID cuenta 1:", id(cuenta1))
    print("ID cuenta 2:", id(cuenta2))

    # Enviar mensajes a los métodos
    print("=== MÉTODOS CONSULTORES ===")
    print(cuenta1.perfil_publico())
    print("Email:", cuenta1.consultar_email())
    print("¿Está activa?", cuenta1.esta_activa())
    print("¿Puede iniciar sesión?", cuenta1.puede_iniciar_sesion())

    # Modificar solamente la primera cuenta
    print("\n=== MÉTODOS MODIFICADORES ===")
    cuenta1.cambiar_email("nuevo@formacion.local")
    cuenta1.registrar_intento_fallido()

    print("Email de Laura:", cuenta1.consultar_email())
    print("Email de Carlos:", cuenta2.consultar_email())

    # Demostrar los intentos fallidos
    cuenta1.registrar_intento_fallido()
    cuenta1.registrar_intento_fallido()

    print("¿Cuenta de Laura activa?", cuenta1.esta_activa())
    print("¿Cuenta de Carlos activa?", cuenta2.esta_activa())

    # Mostrar atributo de clase
    print("=== ATRIBUTOS DE CLASE ===")
    print("Máximo de intentos:", CuentaUsuario.MAX_INTENTOS)
    print("Dominio:", CuentaUsuario.dominio)

    # Acceder al atributo privado mediante name mangling
    print("=== ATRIBUTO PRIVADO ===")
    print(cuenta1._CuentaUsuario__password_hash)

    print("El name mangling no proporciona seguridad real.")
