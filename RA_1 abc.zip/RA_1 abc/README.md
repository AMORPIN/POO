
# Gestión de cuentas de usuario

## 1. Explicación del modelo

El programa utiliza una clase llamada CuentaUsuario para representar las cuentas de los usuarios de una plataforma de formación.

Cada cuenta contiene un nombre, un email, una contraseña simulada mediante una cadena, un estado de actividad y un contador de intentos fallidos.

La clase también tiene dos atributos compartidos: MAX_INTENTOS y dominio.

## 2. Ejemplos de ejecución

Se crean dos cuentas, Laura y Carlos.

Se muestran sus datos mediante __dict__ y se comprueba que son objetos diferentes utilizando is e id().

Después se modifica el email de Laura y se comprueba que el email de Carlos permanece igual.

También se registran tres intentos fallidos en la cuenta de Laura. Al alcanzar el máximo permitido, la cuenta se desactiva.

## 3. Atributos de instancia y de clase

Los atributos de instancia pertenecen a cada objeto y pueden tener valores diferentes.

Por ejemplo, cada usuario tiene su propio nombre y email.

Los atributos de clase son compartidos por todos los objetos de la clase. En este programa son MAX_INTENTOS y dominio.

## 4. Métodos consultores y modificadores

Los métodos consultores permiten consultar información sin modificar el estado del objeto.

Ejemplos: esta_activa(), puede_iniciar_sesion(), perfil_publico() y consultar_email().

Los métodos modificadores permiten cambiar los datos o el estado de la cuenta.

Ejemplos: activar(), desactivar(), cambiar_email(), registrar_intento_fallido() y reiniciar_intentos().

## 5. Reflexión sobre la visibilidad por convención

Python utiliza convenciones para indicar la visibilidad de los atributos.

Un atributo público no lleva guion bajo, uno protegido comienza con un guion bajo y uno privado comienza con dos guiones bajos.

El name mangling modifica el nombre interno de los atributos privados, pero no proporciona seguridad real ni impide completamente su acceso.
